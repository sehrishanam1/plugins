/**
 * Live Score Slider - Auto Refresh Script
 * Refreshes cricket score slider every 2 seconds
 */

jQuery(document).ready(function ($) {
    function loadLiveScores() {
        $.ajax({
            url: lcs_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'lcs_get_live_cricket',
                security: lcs_ajax.nonce
            }, 
            beforeSend: function () {
                $('#live-cricket-container').html('<div class="loading-text">Refreshing scores...</div>');
            },
            success: function (response) {
                // $('.live-card').html(response);
                
                console.log(response);
            },
            error: function () {
                $('#live-cricket-container').html('<div class="no-match">⚠️ Error loading scores</div>');
            }
        });
    }

    loadLiveScores(); // First load
    setInterval(loadLiveScores, 60000); // ⏱️ Refresh every 1 minute
});
